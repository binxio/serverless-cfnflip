class NilClass
  def try_dup
    self
  end
end
